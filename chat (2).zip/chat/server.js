const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

// Create a new Express application
const app = express();

// Create an HTTP server
const server = http.createServer(app);

// Attach Socket.IO to the server
const io = socketIo(server);

// Serve static files from the "public" directory
app.use(express.static('public'));

// Listen for incoming connections from clients
io.on('connection', (socket) => {
  console.log('A user connected');
  let username = 'Anonymous';
  const clientIp = socket.handshake.address;

  // Handle user joining with a name
  socket.on('join', (name) => {
    username = name || 'Anonymous';
    console.log(`User ${username} connected from IP: ${clientIp}`);
  });

  // Listen for chat messages
  socket.on('chat message', (msg) => {
    const timestamp = new Date().toLocaleTimeString();
    console.log(`Message from ${username} (${clientIp}): ${msg}`);
    // Broadcast the message to all clients
    io.emit('chat message', { msg, sender: username, timestamp, ip: clientIp });
  });

  // Listen for user disconnection
  socket.on('disconnect', () => {
    console.log(`User ${username} disconnected`);
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
