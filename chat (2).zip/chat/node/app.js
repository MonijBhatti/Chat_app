const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;

// Set storage engine
const storage = multer.diskStorage({
  destination: './public/uploads/',
  filename: function (req, file, cb) {
    const timestamp = Date.now();
    const caption = req.body.caption ? req.body.caption.replace(/\s+/g, '_') : 'file';
    cb(null, `${caption}-${timestamp}${path.extname(file.originalname)}`);
  }
});

// Init upload
const upload = multer({
  storage: storage,
  limits: { fileSize: 10000000 } // 10MB
}).single('myFile');

// EJS
app.set('view engine', 'ejs');

// Public folder
app.use(express.static('./public'));

// Middleware to parse form data
app.use(express.urlencoded({ extended: false }));

// Routes
app.get('/', (req, res) => res.render('index'));

app.post('/upload', (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      res.render('index', { msg: err });
    } else {
      if (req.file == undefined) {
        res.render('index', { msg: 'No file selected!' });
      } else {
        const filePath = `/uploads/${req.file.filename}`;
        const fileName = req.file.filename;

        // Render list view with file name and path
        res.render('list', { files: [{ name: fileName, path: filePath }] });
      }
    }
  });
});

// Route to list all uploaded files
app.get('/files', (req, res) => {
  const uploadDir = './public/uploads/';
  fs.readdir(uploadDir, (err, files) => {
    if (err) {
      res.status(500).send('Unable to scan files!');
    } else {
      const fileDetails = files.map(file => ({
        name: file,
        path: `/uploads/${file}`
      }));
      res.render('list', { files: fileDetails });
    }
  });
});

app.listen(port, () => console.log(`Server started on port ${port}`));
